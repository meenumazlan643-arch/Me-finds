# Meenu Finds — Free Dropshipping Store

## Quick setup
1. Open `index.html` in a browser to test the store.
2. Edit the `WHATSAPP` value near the bottom of `index.html`.
   Example: `919876543210` (India country code +91, no `+`).
3. Replace the sample products in the `products` array with your real products, prices, and images.
4. Upload `index.html` to a GitHub repository and enable GitHub Pages.

## Important
This is a frontend store. It stores the cart locally in the visitor's browser and sends the order to your WhatsApp. It does not process card/UPI payments automatically.
